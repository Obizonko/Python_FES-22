
'''
#ЧАСТИНА 1

import re
from typing import Tuple

#Функція read_file()приймає аргумент, який є шляхом до текстового файлу для читання. Він повертає кортеж, що містить вміст файлу, кількість слів і кількість речень.
def read_file(file_path= '/Users/fok/Desktop/LAB1/1.txt') -> Tuple[str, int, int]:
 
 #Відкриваємо файл та читаємо його вміст
    with open(file_path, 'r') as f:
        file_content = f.read()

    # Підраховуємо кільксть слів
    words_count = len(re.findall(r'\b\w+\b', file_content))

    # Підраховуємо кількість речень
    sentence_count = len(re.findall(r'\.|\?|\!', file_content))

#повертаємо кортеж, що містить вміст файлу, кількість слів і кількість речень.
    return file_content, words_count, sentence_count

#виводимо результат на екран
result = read_file('/Users/fok/Desktop/LAB1/1.txt')
print(result)

'''


'''

#ЧАСТИНА2

from typing import Dict
#Функція  приймає один аргумент , що вказує на шлях до файлу
#повертає словник (Dict) у якому ключами є паліндромні слова з файлу, а значеннями - кількість їх входжень у файл.
def get_all_palindromes(file_path='/Users/fok/Desktop/LAB1/2.txt') -> Dict[str, int]:

 #Відкриваємо файл та читаємо його вміст
    with open(file_path, 'r') as file:
        content = file.read()


#функція використовує check_palindrome() для перевірки кожного слова з файлу та, якщо слово є паліндромом, додає його до словника palindromes. 
# Якщо слово вже є в словнику, функція збільшує значення для відповідного ключа на одиницю. У кінці функція повертає отриманий словник.
    palindromes = {}
    words = content.split()
    for word in words:
        if check_palindrome(word):
            if word in palindromes:
                palindromes[word] += 1
            else:
                palindromes[word] = 1
    return palindromes


#Функція check_palindrome приймає один аргумент word та повертає логічне значення True, якщо слово є паліндромом, та False у іншому випадку. 
# Для перевірки того, чи є слово паліндромом, функція використовує зріз [::-1], який повертає реверсовану копію рядка.
#  Далі функція порівнює оригінальне слово з його реверсованою копією та повертає True, якщо вони рівні, і False у іншому випадку.

def check_palindrome(word: str) -> bool:
    
    # Реверс
    reversed_word = word[::-1]

    # Перевірка
    if word == reversed_word:
        return True
    else:
        return False

#вивід результату
print(get_all_palindromes('/Users/fok/Desktop/LAB1/2.txt'))


'''


'''
#ЧАСТИНА 3

from typing import Dict

#Функція  приймає один аргумент , що вказує на шлях до файлу
#повертає словник (Dict) у якому ключами  є знайдені палінграми з файлу, а значеннями - кількість їх входжень у файл.
def get_palingrams(file_path='/Users/fok/Desktop/LAB1/2.txt') -> Dict[str, str]:

    #Відкриваємо файл та читаємо його вміст
    with open(file_path, 'r') as file:
        content = file.read()

#функція використовує метод split() для розбиття вмісту файлу на окремі слова та перебирає кожне слово i з масиву words. 
    palingrams = {}
    words = content.split()

    for i in range(len(words)):
    # Перевіряємо наявність паліграм, починаючи з кожного слова та об'єднуємо їх у фразу методом join() з використанням пробілів. 
        for j in range(i+1, len(words)):
            phrase = ' '.join(words[i:j+1])
            #якщо отримана фраза є паліндромом, вона додається до словника palingrams з відповідним значенням кількості входжень.
            if check_palingram(phrase):
                if phrase in palingrams:
                   palingrams[phrase] += 1
                else:
                    palingrams[phrase] = 1
    return palingrams


#еревіряє, чи є отримана фраза палінграмом. Спочатку фраза приводиться до нижнього регістру та видаляються пробіли з допомогою методів replace() та lower(). 
# Потім використовується зріз [::-1], щоб отримати реверсовану копію фрази, та порівнюється з оригіналом.
def check_palingram(phrase: str) -> bool:
   #Видалити пробіли та перетворити на нижній регістр
    phrase = phrase.replace(' ', '').lower()
    # Перевіряємо, чи фраза читається так само в зворотному порядку
    return phrase == phrase[::-1]

print(get_palingrams('/Users/fok/Desktop/LAB1/2.txt'))


'''

'''
#ЧАСТИНА 4 

from typing import Dict

def get_same_letters_word(file_path='/Users/fok/Desktop/LAB1/2.txt') -> Dict[str, int]:
    with open(file_path, 'r') as file:
        content = file.read()

#Функція створює словник result, в якому будуть зберігатися пари слів, що складаються з одних і тих же букв. 
#Для цього проходяться всі комбінації слів в змінній words за допомогою двох вкладених циклів for.
    result = {}
    words = content.split()

#Для кожної пари слів функція сортує всі букви кожного слова за допомогою функції sorted(), потім об'єднує ці букви в одну строку за допомогою join().
#  Якщо результат для обох слів є однаковим, то слова додаються в словник result зі словом words[i] як ключ та словом words[j] як значення.
    for i in range(len(words)):
        for j in range(i + 1, len(words)):
            a = sorted(words[i])
            b = sorted(words[j])
            if ''.join(a) == ''.join(b):
                result[words[i]] = words[j]

#функція повертає словник зі всіма парами слів, де перше слово має ті самі букви, що й друге.
    return result

print(get_same_letters_word(file_path='/Users/fok/Desktop/LAB1/2.txt'))

'''